import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  GoogleMap,
  LoadScript,
  DrawingManager,
  Polygon,
  Marker,
  OverlayView,
  Circle,
  InfoWindowF,
} from "@react-google-maps/api";
import "./App.css";
import CameraIcon from "../public/images/camera_icon.svg";

const libraries = ["drawing"];

const containerStyle = {
  width: "100%",
  height: "100%",
};

const center = {
  lat: 23.0225,
  lng: 72.5714,
};

const getOverlayPosition = (position) => ({
  lat: position[0],
  lng: position[1],
});

const savedCameras = [
  {
    id: 1,
    position: [23.096260556560527, 72.54187424316407],
    rotation: 145,
    focal: 79,
    focalShape: "circular",
    peopleCount: 24,
  },
  {
    id: 3,
    position: [22.972013141934788, 72.60240633621217],
    rotation: 90,
    focal: 100,
    focalShape: "fan",
    peopleCount: 2,
  },
];

const savedPolygons = [
  {
    id: 1741695789818,
    path: [
      {
        lat: 23.124364210845144,
        lng: 72.5218327774048,
      },
      {
        lat: 23.118996551662885,
        lng: 72.59805042877198,
      },
      {
        lat: 23.0798377222452,
        lng: 72.59118397369386,
      },
      {
        lat: 23.08425945195532,
        lng: 72.51015980377198,
      },
    ],
  },
  {
    id: 1741695798073,
    path: [
      {
        lat: 22.999273649901422,
        lng: 72.59839375152589,
      },
      {
        lat: 22.947118310142923,
        lng: 72.5716145767212,
      },
      {
        lat: 22.96197672934313,
        lng: 72.64062245025636,
      },
    ],
  },
];

const GoogleMapComponent = () => {
  const [polygons, setPolygons] = useState([]);
  const [map, setMap] = useState(null);
  const mapRef = useRef();
  const draggedCamera = useRef(null);
  const polygonRefs = useRef({});
  const circleRefs = useRef({});
  const drawingManagerRef = useRef(null);

  console.log(`drawingManagerRef => `, drawingManagerRef);
  console.log(`mapRef => `, mapRef);

  const [notifications, setNotifications] = useState({});

  console.log(`notifications => `, notifications);
  const [cameras, setCameras] = useState([
    { id: 1, rotation: 0, focal: 0, peopleCount: 24 },
    { id: 2, rotation: 45, focal: 0, peopleCount: 67 },
    { id: 3, rotation: 90, focal: 0, peopleCount: 2 },
  ]);
  const [mapCameras, setMapCameras] = useState([]);

  // useEffect(() => {
  //   if (window.google) {
  //     setPolygons(savedPolygons);
  //     setMapCameras(savedCameras);
  //   } else {
  //     console.warn("Google Maps API not loaded yet");
  //   }
  // }, []);

  //Simulating random event notifications
  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     const randomCamera =
  //       mapCameras[Math.floor(Math.random() * mapCameras.length)];
  //     if (randomCamera) {
  //       setNotifications((prev) => ({
  //         ...prev,
  //         [randomCamera.id]: `Event at ${new Date().toLocaleTimeString()}`,
  //       }));

  //       // Remove the notification after 5 seconds
  //       setTimeout(() => {
  //         setNotifications((prev) => {
  //           const updated = { ...prev };
  //           delete updated[randomCamera.id];
  //           return updated;
  //         });
  //       }, 5000);
  //     }
  //   }, 7000); // Every 7 seconds

  //   return () => clearInterval(interval);
  // }, [mapCameras]);

  // Handles completion of a new polygon drawing on the map and stores its path
  const handlePolygonComplete = (polygon) => {
    const path = polygon
      .getPath()
      .getArray()
      .map((coord) => ({
        lat: coord.lat(),
        lng: coord.lng(),
      }));
    const id = Date.now();

    setPolygons((prevPolygons) => [...prevPolygons, { id, path }]);

    // Store reference to the polygon instance
    polygonRefs.current[id] = polygon;
    polygon.setMap(null);
  };

  // Track which camera is being dragged
  // Stores the ID of the camera being dragged
  const handleDragStart = (id) => {
    draggedCamera.current = id;
  };

  // Allow camera to be dragged over the map
  // Allows drag-over by preventing default behavior
  const handleDragOver = (event) => {
    event.preventDefault();
  };

  // Handles dropping a dragged camera onto the map at the center position
  const handleDrop = (event) => {
    // debugger;
    event.preventDefault();
    if (!map) return;
    const mapCenter = map.getCenter();
    const id = draggedCamera.current;

    // Check if the camera is already placed on the map
    const isAlready = mapCameras.filter((item) => item.id === id);

    if (isAlready?.length > 0) {
      alert("Camera already present in the map");
      draggedCamera.current = null;
      return;
    }

    // Add camera at the center of the map
    setMapCameras((prev) => [
      ...prev,
      {
        id,
        position: [mapCenter.lat(), mapCenter.lng()],
        rotation: cameras.find((cam) => cam.id === id)?.rotation,
        focal: cameras.find((cam) => cam.id === id)?.focal,
        focalShape: "fan", // Default shape,
        peopleCount: cameras.find((cam) => cam.id === id)?.peopleCount,
      },
    ]);

    draggedCamera.current = null; // Reset dragged camera
  };

  // Updates camera's rotation or focal value when the slider changes
  const handleSliderChange = (id, field, value) => {
    setMapCameras((prev) =>
      prev.map((cam) => (cam.id === id ? { ...cam, [field]: value } : cam))
    );
  };

  // Toggles camera focal shape between 'fan' and 'circular'
  const handleShapeToggle = (id) => {
    setMapCameras((prev) =>
      prev.map((cam) =>
        cam.id === id
          ? {
              ...cam,
              focalShape: cam.focalShape === "fan" ? "circular" : "fan",
            }
          : cam
      )
    );
  };

  // Updates polygon path coordinates after editing
  const handlePolygonEdit = (index) => {
    const id = polygons[index].id;
    const updatedPath = polygonRefs.current[id]
      .getPath()
      .getArray()
      .map((coord) => ({
        lat: coord.lat(),
        lng: coord.lng(),
      }));

    setPolygons((prevPolygons) =>
      prevPolygons.map((polygon, i) =>
        i === index ? { ...polygon, path: updatedPath } : polygon
      )
    );
  };

  // Delete a polygon from the map and state
  const handlePolygonDelete = (index) => {
    const id = polygons[index].id;
    polygonRefs.current[id]?.setMap(null); // Remove from the map
    delete polygonRefs.current[id];
    setPolygons((prevPolygons) => prevPolygons.filter((_, i) => i !== index));
  };

  // Updates camera position after it is dragged and dropped to a new location
  const handleDragEnd = (id, lat, lng) => {
    // debugger;
    setMapCameras((prev) =>
      prev.map((cam) =>
        cam.id === id ? { ...cam, position: [lat, lng] } : cam
      )
    );
  };

  const getRotatedSvg = (rotation) => {
    // return `data:image/svg+xml;utf8,
    //   <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 100 100">
    //     <g transform="rotate(${rotation}, 50, 50)">
    //       ${CameraIcon}
    //     </g>
    //   </svg>`;
    return `data:image/svg+xml;utf8,
      <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
      
        <g transform="rotate(${rotation}, 50, 50)">
          <circle  cx="13" cy="13" r="12.5" fill="black" stroke="white"/>
<path d="M6.30078 6L19.6992 6C19.8653 6 20 6.13477 20 6.30102L20 9.83318C20 9.99942 19.8653 10.1342 19.6992 10.1342L18.9774 10.1342L18.1813 14.4736C18.1551 14.6165 18.0306 14.7203 17.8855 14.7203C17.8116 14.7203 17.7381 14.7165 17.6652 14.7096C17.6893 14.9034 17.7019 15.0989 17.7019 15.2944C17.7019 17.8891 15.5926 20 13 20C10.4073 20 8.29805 17.8891 8.29805 15.2944C8.29805 15.0989 8.31063 14.9035 8.33472 14.7097C8.26207 14.7165 8.18884 14.7203 8.11515 14.7203C7.96998 14.7203 7.84554 14.6165 7.81932 14.4736L7.02328 10.1342L6.30078 10.1342C6.13467 10.1342 6 9.99945 6 9.8332L6 6.30102C6 6.13477 6.13467 6 6.30078 6ZM6.60156 6.60203L6.60156 7.76609L19.3984 7.76609L19.3984 6.60203L6.60156 6.60203ZM8.89961 15.2944C8.89961 17.5571 10.739 19.3979 13 19.3979C15.2609 19.3979 17.1003 17.5571 17.1003 15.2944C17.1003 15.0479 17.0779 14.8015 17.0341 14.5595C16.5323 14.3642 16.0993 13.9997 15.8207 13.5157C15.1631 12.3732 14.1088 11.6911 13.0003 11.6909C11.8919 11.6911 10.8375 12.3732 10.1799 13.5157C9.90116 14 9.4679 14.3646 8.96576 14.5599C8.92209 14.8017 8.89961 15.048 8.89961 15.2944ZM8.36247 14.1004C8.89794 14.0232 9.38034 13.6987 9.65865 13.2151C10.4249 11.8839 11.6741 11.089 13.0003 11.0889C14.3265 11.089 15.5758 11.8839 16.342 13.2151C16.6203 13.6986 17.1027 14.0232 17.6382 14.1005L18.3657 10.1342L7.63491 10.1342L8.36247 14.1004ZM19.3984 9.53216L19.3984 8.36813L6.60156 8.36813L6.60156 9.53219L19.3984 9.53216Z" fill="white"/>
<path d="M13.2733 17.6149C13.3577 17.8062 13.2041 18.0356 12.9952 18.0311C12.7862 18.0356 12.6328 17.8063 12.7172 17.6149C12.8164 17.3691 13.1739 17.3694 13.2733 17.6149Z" fill="#FF8A01"/>
<path d="M12.9968 13.1629C12.9181 13.1629 12.8398 13.1304 12.7839 13.0748C12.5758 12.8647 12.7651 12.5097 13.0556 12.5666C13.2881 12.6091 13.3789 12.9103 13.2097 13.0748C13.1539 13.1302 13.0755 13.163 12.9968 13.1629Z" fill="#FF8A01"/>
<path d="M11.4904 16.8037C11.6793 16.9898 11.5423 17.3192 11.2775 17.3176C11.116 17.3204 10.9733 17.178 10.9765 17.0163C10.9746 16.7513 11.3045 16.6147 11.4904 16.8037Z" fill="#FF8A01"/>
<path d="M14.8303 13.8522C14.7937 13.8672 14.7546 13.8753 14.7151 13.8752C14.449 13.876 14.3141 13.549 14.5023 13.3612C14.6294 13.2284 14.8673 13.2513 14.9655 13.4072C15.0711 13.5575 15.0021 13.7863 14.8303 13.8522Z" fill="#FF8A01"/>
<path d="M14.8866 16.7685C15.132 16.933 15.0151 17.3193 14.7194 17.3196C14.6205 17.3204 14.5237 17.2685 14.4691 17.1858C14.2905 16.9114 14.6124 16.5894 14.8866 16.7685Z" fill="#FF8A01"/>
<path d="M11.2801 13.8772C10.9847 13.8769 10.8672 13.4906 11.1129 13.3261C11.3874 13.1471 11.7091 13.4688 11.5306 13.7434C11.4759 13.8261 11.3791 13.878 11.2801 13.8772Z" fill="#FF8A01"/>
<path d="M15.4295 15.5972C15.2632 15.5972 15.1284 15.4624 15.1284 15.2961C15.1284 15.1299 15.2632 14.9951 15.4295 14.9951C15.5957 14.9951 15.7305 15.1299 15.7305 15.2961C15.7305 15.4624 15.5957 15.5972 15.4295 15.5972Z" fill="#FF8A01"/>
<path d="M10.5662 15.5981C10.3999 15.5981 10.2652 15.4634 10.2652 15.2971C10.2652 15.1309 10.3999 14.9961 10.5662 14.9961C10.7324 14.9961 10.8672 15.1309 10.8672 15.2971C10.8672 15.4634 10.7324 15.5981 10.5662 15.5981Z" fill="#FF8A01"/>
<path d="M13.0036 16.5426C13.6909 16.5426 14.25 15.9831 14.25 15.2952C14.25 14.6074 13.6909 14.0479 13.0036 14.0479C12.3163 14.0479 11.7572 14.6074 11.7572 15.2952C11.7572 15.9831 12.3163 16.5426 13.0036 16.5426ZM13.0036 14.6499C13.3592 14.6499 13.6484 14.9394 13.6484 15.2953C13.6484 15.6511 13.3592 15.9406 13.0036 15.9406C12.648 15.9406 12.3588 15.6511 12.3588 15.2953C12.3588 14.9394 12.648 14.6499 13.0036 14.6499Z" fill="#FF8A01"/>
        </g>
      </svg>`;
  };

  // Creates an array of points representing the camera's field of view (arc or circle shape)
  const createFocalArc = (position, rotation, focal, focalShape) => {
    // debugger;
    if (focal === 0) return null;
    const arc = [];
    const steps = 20; // Number of points in the arc
    const radius = focal * 10;

    if (focalShape === "circular") {
      for (let i = 0; i <= 360; i += 360 / steps) {
        const angle = ((rotation + i) * Math.PI) / 180;
        const lat = position[0] + (radius / 111320) * Math.cos(angle);
        const lng =
          position[1] +
          (radius / (111320 * Math.cos(position[0] * (Math.PI / 180)))) *
            Math.sin(angle);
        arc.push({ lat, lng });
      }

      // Close the circle by adding the first point at the end
      arc.push(arc[0]);
      return arc;
    }

    // Fan-shaped focal area
    for (let i = -45; i <= 45; i += 90 / steps) {
      const angle = ((rotation + i) * Math.PI) / 180;
      const lat = position[0] + (radius / 111320) * Math.cos(angle);
      const lng =
        position[1] +
        (radius / (111320 * Math.cos(position[0] * (Math.PI / 180)))) *
          Math.sin(angle);
      arc.push({ lat, lng });
    }

    return [
      { lat: position[0], lng: position[1] },
      ...arc,
      { lat: position[0], lng: position[1] },
    ];
  };

  // Removes the drawn field of view (circle/arc) from the map for a specific camera
  const removeCircle = (id) => {
    // debugger;
    if (circleRefs.current[id]) {
      circleRefs.current[id].setMap(null);
      delete circleRefs.current[id];
    }
  };

  // Collects and prepares all polygon and camera data to save or send to backend
  const handleSave = () => {
    // debugger;
    const cameraData = mapCameras?.map((cam) => {
      return {
        id: cam.id,
        position: {
          x: cam.position[0],
          y: cam.position[1],
        },
        ...cam,
      };
    });

    const data = {
      polygons,
      cameras: cameraData,
    };
    console.log("Saved Data:", data);
    // Send data to backend or store locally as required
  };

  // Load polygons and cameras onto the map once Google Map is ready
  const onMapLoad = (map) => {
    if (window.google) {
      setPolygons(savedPolygons);
      setMapCameras(savedCameras);
    }
  };

  // Sets map instance when the Google map is loaded and configures view settings (tilt and map type)
  const handleMapLoad = useCallback((map) => {
    // debugger;
    setMap(map); // Set map state
    //onMapLoad(map); // Load markers and polygons after map load
    map.setTilt(60); // Enables 3D tilt view
    map.setMapTypeId("satellite"); // Use 'hybrid' for street names over satellite
  }, []);

  // useEffect(() => {
  //   // Cleanup function that will run when the component unmounts
  //   return () => {
  //     debugger;
  //     if (map) {
  //       // Optionally, remove any event listeners from the map instance
  //       google.maps.event.clearInstanceListeners(map); // Clears all event listeners attached to the map
  //     }
  //     setMap(null); // Clear the map reference
  //   };
  // }, [map]); // This will run whenever the map changes or when the component unmounts

  return (
    <div className="app-container">
      {/* Sidebar with list of cameras */}
      <div className="sidebar">
        <h2>Camera List</h2>
        {cameras.map((cam) => (
          <div key={cam.id} className="camera-item">
            <div
              className="camera-icon"
              draggable
              onDragStart={() => handleDragStart(cam.id)}
            >
              {/* 📷 */}
              <img
                src={window.location.origin + "/images/camera_icon.svg"}
                alt="Camera Icon"
                style={{
                  width: "35px",
                  height: "35px",
                }}
              />
            </div>
            <p>Camera #{cam.id}</p>

            {/* Slider to adjust rotation */}
            <label>
              Rotation:
              <input
                type="range"
                min="0"
                max="360"
                value={
                  mapCameras.find((c) => c.id === cam.id)?.rotation ||
                  cam.rotation
                }
                onChange={(e) =>
                  handleSliderChange(
                    cam.id,
                    "rotation",
                    parseInt(e.target.value)
                  )
                }
              />
            </label>
            <br />

            {/* Slider to adjust focal distance */}
            <label>
              Focal Distance:
              <input
                type="range"
                min="0"
                max="100"
                value={
                  mapCameras.find((c) => c.id === cam.id)?.focal || cam.focal
                }
                onChange={(e) =>
                  handleSliderChange(cam.id, "focal", parseInt(e.target.value))
                }
              />
            </label>

            {/* Button to toggle between focal shapes (Circle or Fan) */}
            <button
              onClick={() => {
                removeCircle(cam.id);
                handleShapeToggle(cam.id);
              }}
            >
              {mapCameras.find((c) => c.id === cam.id)?.focalShape ===
              "circular"
                ? "Switch to Fan"
                : "Switch to Circle"}
            </button>
          </div>
        ))}

        {/* Save button */}
        <button onClick={handleSave} className="save-button">
          Save
        </button>
      </div>

      {/* Main Map Container */}
      <div
        className="map-container"
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e)}
      >
        {/* Load Google Maps with necessary libraries */}
        <LoadScript
          googleMapsApiKey="AIzaSyC5Z4ltoHjqA-_u4WaF1NXq_yOVWMIgFI0"
          libraries={libraries}
        >
          <GoogleMap
            mapContainerStyle={containerStyle}
            center={center}
            zoom={12}
            // onLoad={(map) => setMap(map)}
            // onLoad={onMapLoad}
            onLoad={handleMapLoad}
            ref={mapRef}
          >
            {/* Enable DrawingManager for creating polygons */}
            {map && window.google && (
              <DrawingManager
                //onLoad={(dm) => (drawingManagerRef.current = dm)} // Save instance to ref
                options={{
                  drawingControl: true,
                  drawingControlOptions: {
                    position: window.google.maps.ControlPosition.TOP_CENTER,
                    drawingModes: ["polygon"],
                  },
                  polygonOptions: {
                    fillColor: "blue",
                    fillOpacity: 0.4,
                    strokeColor: "blue",
                    strokeOpacity: 0.8,
                    strokeWeight: 2,
                  },
                }}
                onPolygonComplete={handlePolygonComplete}
              />
            )}

            {/* Render all drawn polygons */}
            {polygons.map((polygon, index) => (
              <Polygon
                key={polygon.id}
                paths={polygon.path}
                options={{
                  fillColor: "#87CEEB", // Light blue
                  fillOpacity: 0.4,
                  strokeColor: "#87CEEB", // Light blue border
                  strokeOpacity: 0.8,
                  strokeWeight: 2,
                  editable: true, // Make polygon editable
                }}
                onLoad={(polygonInstance) =>
                  (polygonRefs.current[polygon.id] = polygonInstance)
                }
                onMouseUp={() => handlePolygonEdit(index)} // Save changes after editing
                onRightClick={() => handlePolygonDelete(index)} // Delete polygon on right-click
              />
            ))}

            {/* Render all camera markers with focal overlays */}
            {mapCameras.map((cam) => {
              {
                /* const arc =
                cam.focalShape === "fan"
                  ? createFocalArc(
                      cam.position,
                      cam.rotation,
                      cam.focal,
                      cam.focalShape
                    )
                  : null;
              const circularCenter =
                cam.focalShape === "circular"
                  ? { lat: cam.position[0], lng: cam.position[1] }
                  : null;
              const circularRadius =
                cam.focalShape === "circular" ? cam.focal * 10 : null; */
              }
              const arc = cam.focalShape
                ? createFocalArc(
                    cam.position,
                    cam.rotation,
                    cam.focal,
                    cam.focalShape
                  )
                : null;
              return (
                <React.Fragment key={cam.id}>
                  <Marker
                    position={getOverlayPosition(cam.position)}
                    key={cam.id}
                    draggable
                    onDragEnd={(e) =>
                      handleDragEnd(cam.id, e.latLng.lat(), e.latLng.lng())
                    }
                    icon={{
                      //url: getRotatedSvg(cam.rotation),
                      url: CameraIcon,
                      //                   url: `data:image/svg+xml;utf8,
                      // <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 100 100">
                      //   <g transform="rotate(${cam.rotation}, 50, 50)">
                      //     <circle cx="50" cy="50" r="40" fill="red" />
                      //     <path d="M30 50 L70 50 M50 30 L50 70" stroke="white" stroke-width="5" />
                      //   </g>
                      // </svg>`,
                      scaledSize: new google.maps.Size(35, 35),
                      anchor: new google.maps.Point(15, 15),
                    }}
                  >
                    {notifications[cam.id] && (
                      <InfoWindowF position={{ lat: cam.lat, lng: cam.lng }}>
                        <div
                          style={{
                            fontSize: "14px",
                            fontWeight: "bold",
                            color: "red",
                          }}
                        >
                          🚨 {notifications[cam.id]}
                        </div>
                      </InfoWindowF>
                    )}
                  </Marker>

                  {/* People count overlay near the camera marker */}
                  <OverlayView
                    position={{ lat: cam.position[0], lng: cam.position[1] }}
                    mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
                  >
                    <div
                      style={{
                        position: "absolute",
                        backgroundColor: "rgba(0, 0, 0, 0.7)",
                        color: "white",
                        padding: "4px 8px",
                        borderRadius: "8px",
                        fontSize: "14px",
                        transform: "translate(-50%, -150%)", // Adjust the position above the marker
                        whiteSpace: "nowrap",
                      }}
                    >
                      {/* <p>Camera Id: {cam.id}</p> */}
                      👥 {cam.peopleCount}
                      {/* <p>People Count: {cam.peopleCount}</p> */}
                    </div>
                  </OverlayView>

                  {/* Render focal arc or circle depending on focal shape */}
                  {arc ? (
                    <Polygon
                      paths={arc}
                      options={{
                        fillColor: "green",
                        fillOpacity: 0.5,
                        strokeColor: "green",
                        strokeOpacity: 0.8,
                      }}
                    />
                  ) : null}
                </React.Fragment>
              );
            })}
          </GoogleMap>
        </LoadScript>
      </div>
    </div>
  );
};

export default GoogleMapComponent;
