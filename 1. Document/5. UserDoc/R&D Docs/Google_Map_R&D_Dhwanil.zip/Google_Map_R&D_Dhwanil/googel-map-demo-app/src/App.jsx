import GoogleMapComponent from "./GoogleMapComponent";

function App() {
  return <GoogleMapComponent />;
}

export default App;
