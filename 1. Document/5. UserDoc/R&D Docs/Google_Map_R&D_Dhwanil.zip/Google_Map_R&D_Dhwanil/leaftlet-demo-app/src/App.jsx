import React, { useState, useRef, useEffect } from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  Polygon,
  FeatureGroup,
  Circle,
  Popup,
  Tooltip,
  LayersControl,
} from "react-leaflet";
import { EditControl } from "react-leaflet-draw";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-draw/dist/leaflet.draw.css";
import "./App.css";
import CircularSlider from "@fseehawer/react-circular-slider";
import "./CameraMap.css"; // Import CSS for blinking effect
import CameraIcon from "../public/images/camera_icon.svg";

const savedPolygons = [
  {
    id: 876,
    latlngs: [
      { lat: 23.056194443903127, lng: 72.5292124221359 },
      { lat: 23.05614508474705, lng: 72.52988821940885 },
      { lat: 23.05527636063775, lng: 72.52993649064265 },
      { lat: 23.055291168482032, lng: 72.52943232442313 },
    ],
  },
  {
    id: 1068,
    latlngs: [
      { lat: 23.055621876579945, lng: 72.53164207423626 },
      { lat: 23.05557251721393, lng: 72.53263967973437 },
      { lat: 23.05517764163424, lng: 72.53262895279357 },
      { lat: 23.05516283377747, lng: 72.53224814639371 },
      { lat: 23.05485680437287, lng: 72.53221596557123 },
      { lat: 23.054827188587115, lng: 72.53078391896901 },
      { lat: 23.055207257342897, lng: 72.53078391896901 },
      { lat: 23.05517764163424, lng: 72.53162062035457 },
    ],
  },
];

const savedCameras = [
  {
    id: 1,
    position: [23.0372342607365, 72.58102633236702],
    rotation: 100,
    focal: 60,
    focalShape: "fan",
    peopleCount: 24,
  },
];

const App = () => {
  const [polygon, setPolygon] = useState([]);
  const [cameras, setCameras] = useState([
    { id: 1, rotation: 0, focal: 0, peopleCount: 24 },
    { id: 2, rotation: 45, focal: 0, peopleCount: 67 },
    { id: 3, rotation: 90, focal: 0, peopleCount: 2 },
  ]);
  const [mapCameras, setMapCameras] = useState([]);
  const draggedCamera = useRef(null);
  const mapRef = useRef();
  const [activeCamera, setActiveCamera] = useState(null);

  const [notifications, setNotifications] = useState({});

  // useEffect(() => {
  //   setPolygon(savedPolygons);
  //   setMapCameras(savedCameras);
  // }, []);

  //Simulating random event notifications
  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     const randomCamera =
  //       mapCameras[Math.floor(Math.random() * mapCameras.length)];
  //     if (randomCamera) {
  //       setNotifications((prev) => ({
  //         ...prev,
  //         [randomCamera.id]: `Event at ${new Date().toLocaleTimeString()}`,
  //       }));

  //       // Remove the notification after 5 seconds
  //       setTimeout(() => {
  //         setNotifications((prev) => {
  //           const updated = { ...prev };
  //           delete updated[randomCamera.id];
  //           return updated;
  //         });
  //       }, 5000);
  //     }
  //   }, 7000); // Every 7 seconds

  //   return () => clearInterval(interval);
  // }, [mapCameras]);

  console.log(`activeCamera => `, activeCamera);
  //console.log(`polygons => `, polygon);
  const handleDragStart = (id) => {
    draggedCamera.current = id;
  };

  const handleDrop = (event) => {
    event.preventDefault();
    const map = mapRef.current;
    const mapCenter = map.getCenter();
    const id = draggedCamera.current;

    const isAlready = mapCameras.filter((item) => item.id === id);

    if (isAlready?.length > 0) {
      alert("Camera already present in the map");
      draggedCamera.current = null;
      return;
    }

    setMapCameras((prev) => [
      ...prev,
      {
        id,
        position: [mapCenter.lat, mapCenter.lng],
        rotation: cameras.find((cam) => cam.id === id).rotation,
        focal: cameras.find((cam) => cam.id === id).focal,
        focalShape: "fan", // Default shape,
        peopleCount: cameras.find((cam) => cam.id === id).peopleCount,
      },
    ]);

    draggedCamera.current = null; // Reset dragged camera
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handlePolygonCreated = (e) => {
    // const layer = e.layer;
    // const latlngs = layer.getLatLngs();
    // setPolygon(latlngs[0]);
    debugger;
    console.log(e);

    const { layerType, layer } = e;
    if (layerType === "polygon") {
      const { _leaflet_id } = layer;

      setPolygon((layers) => [
        ...layers,
        { id: _leaflet_id, latlngs: layer.getLatLngs()[0] },
      ]);
    }
  };

  const handleDragEnd = (id, e) => {
    const newPos = e.target.getLatLng();
    setMapCameras((prev) =>
      prev.map((cam) =>
        cam.id === id ? { ...cam, position: [newPos.lat, newPos.lng] } : cam
      )
    );
  };

  const handleSliderChange = (id, field, value) => {
    setMapCameras((prev) =>
      prev.map((cam) => (cam.id === id ? { ...cam, [field]: value } : cam))
    );
  };

  const createFocalArc = (center, rotation, focal, shape) => {
    if (focal === 0) return null; // Return null if focal is 0

    const radius = focal / 10000; // Adjust scale to match map distances

    // if (shape === "circular") {
    //   return L.circle(center, { radius: radius * 1000 });
    // }

    const angle = 60; // Fixed coverage angle in degrees
    const numPoints = 10; // Number of points in the arc
    const arc = [];

    for (let i = -angle / 2; i <= angle / 2; i += angle / numPoints) {
      const rad = ((rotation + i) * Math.PI) / 180; // Convert angle to radians
      const lat = center[0] + radius * Math.cos(rad); // Calculate latitude
      const lng = center[1] + radius * Math.sin(rad); // Calculate longitude
      arc.push([lat, lng]);
    }

    // Close the arc by connecting it back to the center
    return [center, ...arc, center];
  };

  const handleSave = () => {
    debugger;
    const cameraData = mapCameras?.map((cam) => {
      return {
        id: cam.id,
        position: {
          x: cam.position[0],
          y: cam.position[1],
        },
        ...cam,
      };
    });

    const data = {
      polygon,
      cameras: cameraData,
    };
    console.log("Saved Data:", data);
    // Send data to backend or store locally as required
  };

  const _onDeleted = (e) => {
    debugger;
    console.log(e);
    const {
      layers: { _layers },
    } = e;

    Object.values(_layers).map(({ _leaflet_id }) => {
      setPolygon((layers) => layers.filter((l) => l.id !== _leaflet_id));
    });
  };

  const handleMarkerRotation = (id, rotationDelta) => {
    setMapCameras((prev) =>
      prev.map((cam) =>
        cam.id === id
          ? { ...cam, rotation: (cam.rotation + rotationDelta) % 360 }
          : cam
      )
    );
  };

  // const handleRotationDrag = (id, e) => {
  //   const camera = mapCameras.find((cam) => cam.id === id);
  //   if (!camera) return;

  //   const handlePos = e.target.getLatLng();
  //   const angle = Math.atan2(
  //     handlePos.lng - camera.position[1],
  //     handlePos.lat - camera.position[0]
  //   );
  //   const rotation = (angle * (180 / Math.PI) + 360) % 360;

  //   setMapCameras((prev) =>
  //     prev.map((cam) => (cam.id === id ? { ...cam, rotation } : cam))
  //   );
  // };

  const handleRotationChange = (value) => {
    setMapCameras((prevCameras) =>
      prevCameras.map((camera) =>
        camera.id === activeCamera ? { ...camera, rotation: value } : camera
      )
    );
  };

  const handleShapeToggle = (id) => {
    setMapCameras((prev) =>
      prev.map((cam) =>
        cam.id === id
          ? {
              ...cam,
              focalShape: cam.focalShape === "fan" ? "circular" : "fan",
            }
          : cam
      )
    );
  };

  return (
    <div className="app-container">
      <div className="sidebar">
        <h2>Camera List</h2>
        {cameras.map((cam) => (
          <div key={cam.id} className="camera-item">
            <div
              className="camera-icon"
              draggable
              onDragStart={() => handleDragStart(cam.id)}
            >
              {/* 📷 */}
              <img src="/images/camera_icon.svg"/>
            </div>
            <p>Camera #{cam.id}</p>
            <label>
              Rotation:
              <input
                type="range"
                min="0"
                max="360"
                value={
                  mapCameras.find((c) => c.id === cam.id)?.rotation ||
                  cam.rotation
                }
                onChange={(e) =>
                  handleSliderChange(
                    cam.id,
                    "rotation",
                    parseInt(e.target.value)
                  )
                }
              />
            </label>
            <br />
            <label>
              Focal Distance:
              <input
                type="range"
                min="0"
                max="100"
                value={
                  mapCameras.find((c) => c.id === cam.id)?.focal || cam.focal
                }
                onChange={(e) =>
                  handleSliderChange(cam.id, "focal", parseInt(e.target.value))
                }
              />
            </label>
            <button onClick={() => handleShapeToggle(cam.id)}>
              {mapCameras.find((c) => c.id === cam.id)?.focalShape ===
              "circular"
                ? "Switch to Fan"
                : "Switch to Circle"}
            </button>
          </div>
        ))}
        <button onClick={handleSave} className="save-button">
          Save
        </button>
      </div>

      <div
        className="map-container"
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e)}
      >
        <MapContainer
          center={[23.0225, 72.5714]}
          zoom={12}
          style={{ height: "100%", width: "100%" }}
          ref={mapRef}
          //maxZoom={20}
        >
          {/* <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          />
          <TileLayer
            url="https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}"
            attribution="Map data ©2024 Google"
          /> */}
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked name="OpenStreetMap">
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
              />
            </LayersControl.BaseLayer>

            <LayersControl.BaseLayer name="Satellite">
              <TileLayer
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                attribution='&copy; <a href="https://www.esri.com/">Esri</a> & contributors'
              />
            </LayersControl.BaseLayer>
          </LayersControl>
          <FeatureGroup>
            <EditControl
              position="topright"
              onCreated={handlePolygonCreated}
              onDeleted={_onDeleted}
              draw={{
                rectangle: false,
                circle: false,
                circlemarker: false,
                polyline: false,
                marker: false,
              }}
            />
          </FeatureGroup>

          {/* If polygon is already present 

          {polygon.map((polygon) => (
            <Polygon
              key={polygon.id}
              positions={polygon.latlngs.map((p) => [p.lat, p.lng])}
              pathOptions={{ color: "blue", weight: 2, fillOpacity: 0.3 }}
            />
          ))} */}

          {mapCameras.map((cam) => {
            const hasAlert = !!notifications[cam.id];
            const arc = createFocalArc(
              cam.position,
              cam.rotation,
              cam.focal,
              cam.focalShape
            );
            const rotationHandlePos = [
              cam.position[0] +
                0.0005 * Math.cos((cam.rotation * Math.PI) / 180),
              cam.position[1] +
                0.0005 * Math.sin((cam.rotation * Math.PI) / 180),
            ];
            return (
              <React.Fragment key={cam.id}>
                <Marker
                  key={cam.id}
                  position={cam.position}
                  draggable
                  eventHandlers={{
                    dragend: (e) => handleDragEnd(cam.id, e),
                    // click: () =>
                    //   setActiveCamera(activeCamera === cam.id ? null : cam.id),
                    //click: () => handleMarkerRotation(cam.id, 15),
                  }}
                  icon={L.divIcon({
                    className: hasAlert
                      ? "camera-icon blinking"
                      : "camera-icon",
                    html: `<div style="transform: rotate(${
                      cam.rotation
                    }deg); font-size: 20px; color: ${
                      hasAlert ? "red" : "black"
                    };"><img src="/images/camera_icon.svg"/></div>`,
                  })}
                >
                  <Popup autoOpen>
                    <div style={{ textAlign: "center" }}>
                      <h4>Camera ID: {cam.id}</h4>
                      <p>
                        People Count: <strong>{cam.peopleCount || 0}</strong>
                      </p>
                    </div>
                  </Popup>
                  {/* <Tooltip permanent direction="top">
                    <div style={{ textAlign: "center" }}>
                      <h4>
                        Camera ID: {cam.id}
                      </h4>
                      <p>
                        People: <strong>{cam.peopleCount || 0}</strong>
                      </p>
                    </div>
                  </Tooltip> */}
                  {hasAlert && (
                    <Tooltip permanent direction="top">
                      <div className="alert-tooltip">
                        🚨 {notifications[cam.id] || "Alert!"}
                      </div>
                    </Tooltip>
                  )}
                </Marker>
                {/* <Marker
                  position={rotationHandlePos}
                  draggable
                  eventHandlers={{ dragend: (e) => handleRotationDrag(cam.id, e) }}
                  icon={L.divIcon({
                    className: "rotation-handle",
                    html: "🔄",
                  })}
                /> */}
                {activeCamera && (
                  <div
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                      zIndex: 1000,
                    }}
                  >
                    <CircularSlider
                      width={100}
                      height={100}
                      min={0}
                      max={360}
                      value={
                        mapCameras.find((c) => c.id === activeCamera).rotation
                      }
                      onChange={handleRotationChange}
                    />
                  </div>
                )}
                {arc &&
                  (cam.focalShape === "circular" ? (
                    <Circle
                      center={cam.position}
                      radius={cam.focal * 10}
                      color="green"
                    />
                  ) : (
                    <Polygon positions={arc} color="green" opacity={1.5} />
                  ))}
              </React.Fragment>
            );
          })}
        </MapContainer>
      </div>
    </div>
  );
};

export default App;
